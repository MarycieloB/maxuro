if (!customElements.get("product-modal")) {
    class ProductModal extends ModalDialog {
        constructor() {
            super();
            this.bodyClass = "product-modal__opened";
            this.media = this.querySelectorAll(
                ".product-media-modal--inner > *"
            );
            this.mediaThumbs = this.querySelectorAll(
                ".product-media-modal__thumbs > a"
            );
            window.addEventListener("popstate", (event) => {
                this.hasAttribute("open") && this.hide();
            });
        }

        connectedCallback() {
            if (!this.media || !this.mediaThumbs) return;

            this.mediaThumbs.forEach((thumb) => {
                thumb.addEventListener("click", this.showThumbMedia.bind(this));
            });
        }

        hide() {
            super.hide();
            document.body.classList.remove(this.bodyClass);
            window.pauseAllMedia();
        }

        show(opener) {
            window.location.hash = "product-modal";
            super.show(opener);
            document.body.classList.add(this.bodyClass);
            this.showActiveMedia();
        }

        showActiveMedia() {
            this.querySelectorAll(
                `[data-media-id]:not([data-media-id="${this.openedBy.getAttribute(
                    "data-media-id"
                )}"])`
            ).forEach((element) => {
                element.classList.remove("active");
            });
            const activeMedia = this.querySelector(
                `[data-media-id="${this.openedBy.getAttribute(
                    "data-media-id"
                )}"]`
            );
            activeMedia.classList.add("active");
            activeMedia.scrollIntoView();

            this.mediaThumbs?.forEach((thumb) => {
                if (activeMedia.dataset.mediaId === thumb.dataset.mediaId)
                    thumb.classList.add("active");
            });

            if (
                activeMedia.nodeName == "DEFERRED-MEDIA" &&
                activeMedia
                    .querySelector("template")
                    ?.content?.querySelector(".js-youtube")
            )
                activeMedia.loadContent();
        }

        showThumbMedia(e) {
            e.preventDefault();

            this.initLoading().then(() => {
                const currentMediaId = e.target.closest("a").dataset.mediaId;

                this.mediaThumbs.forEach((thumb) =>
                    thumb.classList.remove("active")
                );

                this.media.forEach((media) => {
                    media.classList.remove("active");

                    if (media.dataset.mediaId == currentMediaId) {
                        media.classList.add("active");
                        e.target.closest("a").classList.add("active");

                        media.addEventListener("error", (event) => {
                            this.showLoading();
                            console.error(
                                `Something wrong with the media: ${media}`
                            );
                        });
                    }
                });
            });
        }

        initLoading() {
            return fetchLoaderHTML().then((html) => {
                if (!this.loader) {
                    this.insertAdjacentHTML("afterbegin", html);
                    this.loader = this.querySelector(".loading-overlay");
                }
            });
        }

        showLoading() {
            this.loader && this.loader.classList.remove("hidden");
        }

        hideLoading() {
            this.loader && this.loader.classList.add("hidden");
        }

        disconnectedCallback() {
            this.mediaThumbs.forEach((thumb) => {
                thumb.removeEventListener(
                    "click",
                    this.showActiveMedia.bind(this)
                );
            });
        }
    }

    customElements.define("product-modal", ProductModal);
}
