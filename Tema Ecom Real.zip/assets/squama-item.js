class SquamaItem extends HTMLElement {
    connectedCallback() {
        this.extraPadding = 20;

        this.reinit();
        this.addEventListener("focusin", this.handleFocusIn);
        this.addEventListener("focusout", this.handleFocusOut);
        this.reinit();
    }

    disconnectedCallback() {
        this.removeEventListener("focusin", this.handleFocusIn);
        this.removeEventListener("focusout", this.handleFocusOut);
    }

    handleFocusIn() {
        this.setAttribute("data-focused", "");
    }

    handleFocusOut(event) {
        // remove data-focused when focus is out of squama-item
        if (!this.contains(event.relatedTarget)) {
            this.removeAttribute("data-focused");
            this.scrollTop = 0;
        }
    }

    reinit(squama = false) {
        if (!squama && window.visualViewport.width < 767) {
            this.removeAttribute("data-status");
            this.style.removeProperty("height");
            return;
        }

        setTimeout(() => {
            // Set height for squama item on screens greater 767px.
            // Other wise heigh is 'auto' using css rule
            // if squama product reting more than "0", add squama items height extra padding
            this.style.height = squama
                ? this.clientHeight + this.extraPadding + "px"
                : this.clientHeight + "px";

            this.setAttribute("data-status", "ready");
        }, 100);
    }
}

customElements.define("squama-item", SquamaItem);
