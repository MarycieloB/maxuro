if (!customElements.get("pagination-load-more")) {
    class PaginationLoadMore extends HTMLElement {
        constructor() {
            super();

            this.loadMoreBtn = this.querySelector(".pagination-load-more");
            if (!this.loadMoreBtn) return;
        }

        connectedCallback() {
            window.infiniteScrollObserver = new IntersectionObserver(
                (entries, observer) => {
                    entries.forEach((entry) => {
                        if (entry.isIntersecting) this.loadNextPage();
                    });
                },
                {
                    rootMargin: "0px 0px 0px 0px",
                }
            );

            window.infiniteScrollObserver.observe(this.loadMoreBtn);
        }

        loadNextPage() {
            let loadMoreBtn = this.loadMoreBtn,
                dataListItems = document.querySelector("[data-list-items]");

            //window.loadMoreBtn = this.loadMoreBtn;
            window.scrollLoad = true;

            if (window.scrollLoad) {
                let url = loadMoreBtn.href,
                    sources = [
                        "[data-product-id]",
                        "[data-collection-id]",
                        "[data-article-id]",
                    ];

                this.showLoader();
                window.scrollLoad = false;

                fetch(url)
                    .then((response) => response.text())
                    .then((text) => {
                        this.hideLoader();

                        let itemsChildren,
                            dataHtml = new DOMParser().parseFromString(
                                text,
                                "text/html"
                            );

                        sources.forEach((source) => {
                            itemsChildren = dataHtml.querySelectorAll(
                                `[data-list-items] ${source}`
                            );
                            if (itemsChildren.length == 0) return;

                            // add new items to the end of the list
                            itemsChildren.forEach((item) => {
                                if (
                                    item.nodeName === "LI" ||
                                    item.nodeName === "ARTICLE"
                                )
                                    dataListItems.appendChild(item);
                            });
                        });

                        // if load more button url has param page - next page
                        let ifNextPage = !!dataHtml
                            .querySelector(".pagination-load-more")
                            .href.split("page=")[1];

                        if (ifNextPage) {
                            loadMoreBtn.href = dataHtml.querySelector(
                                ".pagination-load-more"
                            ).href;
                            window.scrollLoad = true;
                        } else {
                            loadMoreBtn.remove();
                            window.infiniteScrollObserver.unobserve(
                                loadMoreBtn
                            );
                        }
                    })
                    .catch(function (err) {
                        console.error(err);
                    });
            }
        }

        showLoader() {
            let btn = this.loadMoreBtn;
            if (!btn.querySelector(".loading-overlay"))
                btn.prepend(createFromTemplate("template-loading-overlay"));

            btn && btn.classList.add("loading");
            if (btn.children[0].classList.contains("hidden"))
                btn.children[0].classList.remove("hidden");
        }

        hideLoader() {
            let btn = this.loadMoreBtn;
            btn.children[0].classList.add("hidden");
            btn && btn.classList.remove("loading");
        }

        disconnectedCallback() {
            window.infiniteScrollObserver.unobserve(this.loadMoreBtn);
        }
    }

    customElements.define("pagination-load-more", PaginationLoadMore);
}
