if (!customElements.get("compare-products-link")) {
    class CompareProductsLink extends HTMLElement {
        constructor() {
            super();

            this.link = this.querySelector("a");
        }

        connectedCallback() {
            this.link?.addEventListener("click", this.onButtonClick.bind(this));
        }

        disconnectedCallback() {
            this.link?.removeEventListener(
                "click",
                this.onButtonClick.bind(this)
            );
        }

        onButtonClick(e) {
            e.preventDefault();
            let popup = document.getElementById(CompareUtils.comparePopup);
            popup?.removeAttribute("hidden"); // show compare popup

            this.showPopupOverlay();
        }

        showPopupOverlay() {
            document.querySelector("body").classList.add("compare--overlay");
        }
    }

    customElements.define("compare-products-link", CompareProductsLink);
}
